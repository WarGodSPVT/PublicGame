package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.FloatingNumber
import com.example.ui.theme.CosmicPurple
import com.example.ui.theme.CosmicViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PlasmaPink
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SupernovaGold
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun CrystalCore(
    currentCombo: Double,
    comboProgress: Float,
    effectiveCpc: Double,
    floatingNumbers: List<FloatingNumber>,
    onTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val scaleAnim = remember { Animatable(1f) }

    // Infinite breathing/pulsing animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Combo status bar
        if (currentCombo > 1.05) {
            Surface(
                color = SpaceCard,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .padding(bottom = 12.dp)
                    .testTag("combo_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Combo Fire",
                        tint = if (currentCombo >= 2.0) PlasmaPink else SupernovaGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = String.format("COMBO x%.1f BOOST", currentCombo),
                        color = if (currentCombo >= 2.0) PlasmaPink else SupernovaGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            LinearProgressIndicator(
                progress = { comboProgress },
                modifier = Modifier
                    .fillMaxWidth(0.55f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (currentCombo >= 2.0) PlasmaPink else NeonCyan,
                trackColor = SpaceCard
            )
            Spacer(modifier = Modifier.height(16.dp))
        } else {
            Spacer(modifier = Modifier.height(38.dp))
        }

        // The Crystal Clickable Area
        Box(
            modifier = Modifier
                .size(240.dp)
                .scale(scaleAnim.value * pulseScale)
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {
                        coroutineScope.launch {
                            scaleAnim.animateTo(0.90f, spring(dampingRatio = 0.4f, stiffness = 1200f))
                            scaleAnim.animateTo(1.0f, spring(dampingRatio = 0.5f, stiffness = 600f))
                        }
                        onTap()
                    }
                )
                .testTag("crystal_core_button"),
            contentAlignment = Alignment.Center
        ) {
            // Orbital energy rings drawn via Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                val outerRadius = size.width * 0.46f
                val midRadius = size.width * 0.38f
                val innerRadius = size.width * 0.28f

                // Outer faint ring
                drawCircle(
                    color = NeonCyan.copy(alpha = 0.25f),
                    radius = outerRadius,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Mid glowing ring
                drawCircle(
                    color = CosmicPurple.copy(alpha = 0.45f),
                    radius = midRadius,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )

                // Core radiant gradient circle
                val brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        NeonCyan,
                        CosmicViolet,
                        Color(0xFF1E0A3C)
                    ),
                    center = center,
                    radius = innerRadius
                )
                drawCircle(
                    brush = brush,
                    radius = innerRadius,
                    center = center
                )

                // Orbiting spark points
                val rad = Math.toRadians(rotationAngle.toDouble())
                val sparkX = center.x + (midRadius * Math.cos(rad)).toFloat()
                val sparkY = center.y + (midRadius * Math.sin(rad)).toFloat()
                drawCircle(
                    color = SupernovaGold,
                    radius = 4.dp.toPx(),
                    center = Offset(sparkX, sparkY)
                )

                val spark2X = center.x + (outerRadius * Math.cos(rad + Math.PI)).toFloat()
                val spark2Y = center.y + (outerRadius * Math.sin(rad + Math.PI)).toFloat()
                drawCircle(
                    color = PlasmaPink,
                    radius = 3.5.dp.toPx(),
                    center = Offset(spark2X, spark2Y)
                )
            }

            // Central Crystal Emblem
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ElectricBolt,
                    contentDescription = "Cosmic Core",
                    tint = Color.White,
                    modifier = Modifier.size(54.dp)
                )
                Text(
                    text = "TAP",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    letterSpacing = 2.sp
                )
            }

            // Floating Numbers overlay
            floatingNumbers.forEach { floating ->
                Text(
                    text = floating.text,
                    color = if (floating.isCritical) PlasmaPink else SupernovaGold,
                    fontSize = if (floating.isCritical) 20.sp else 16.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                x = floating.xOffsetDp.dp.roundToPx(),
                                y = floating.yOffsetDp.dp.roundToPx()
                            )
                        }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Power per tap info pill
        Surface(
            color = SpaceCard,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.testTag("tap_power_pill")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Energy",
                    tint = SupernovaGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.size(6.dp))
                Text(
                    text = String.format("+%.1f crystals / tap", effectiveCpc),
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium,
                    fontSize = 13.sp
                )
            }
        }
    }
}
