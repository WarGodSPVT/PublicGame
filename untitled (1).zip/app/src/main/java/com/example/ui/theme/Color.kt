package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SpaceBlack = Color(0xFF090A10)
val SpaceDark = Color(0xFF10121C)
val SpaceCard = Color(0xFF191D2C)
val SpaceCardElevated = Color(0xFF22273B)

val NeonCyan = Color(0xFF00F5FF)
val NeonCyanDim = Color(0xFF009AA6)
val CosmicPurple = Color(0xFFB388FF)
val CosmicViolet = Color(0xFF7C4DFF)
val SupernovaGold = Color(0xFFFFD54F)
val PlasmaPink = Color(0xFFFF4081)
val EmeraldGlow = Color(0xFF00E676)

val TextPrimary = Color(0xFFF0F3FA)
val TextSecondary = Color(0xFF9EA7C0)
val TextMuted = Color(0xFF646E8C)

