package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CosmicColorScheme = darkColorScheme(
  primary = NeonCyan,
  onPrimary = SpaceBlack,
  primaryContainer = NeonCyanDim,
  onPrimaryContainer = Color.White,
  secondary = CosmicPurple,
  onSecondary = SpaceBlack,
  secondaryContainer = CosmicViolet,
  onSecondaryContainer = Color.White,
  tertiary = SupernovaGold,
  onTertiary = SpaceBlack,
  background = SpaceBlack,
  onBackground = TextPrimary,
  surface = SpaceDark,
  onSurface = TextPrimary,
  surfaceVariant = SpaceCard,
  onSurfaceVariant = TextSecondary,
  outline = SpaceCardElevated
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = CosmicColorScheme,
    typography = Typography,
    content = content
  )
}

