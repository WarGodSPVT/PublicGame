package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameRegistry
import com.example.model.UpgradeDefinition
import com.example.ui.BuyMultiplier
import com.example.ui.theme.CosmicPurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SpaceCardElevated
import com.example.ui.theme.SupernovaGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun UpgradesView(
    crystals: Double,
    upgradeLevels: Map<String, Int>,
    buyMultiplier: BuyMultiplier,
    onToggleMultiplier: () -> Unit,
    onBuyUpgrade: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Multiplier selector bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Click Enhancements",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Boost crystals generated per tap",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            // Buy mode toggle chip
            FilterChip(
                selected = true,
                onClick = onToggleMultiplier,
                label = {
                    Text(
                        text = "Buy: ${buyMultiplier.label}",
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NeonCyan,
                    selectedLabelColor = Color.Black
                ),
                modifier = Modifier.testTag("buy_multiplier_chip")
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(GameRegistry.CLICK_UPGRADES) { def ->
                val level = upgradeLevels[def.id] ?: 0
                val (count, cost) = calculateUpgradeCost(def, level, buyMultiplier, crystals)
                val canAfford = count > 0 && crystals >= cost

                UpgradeItemCard(
                    definition = def,
                    level = level,
                    buyCount = count,
                    cost = cost,
                    canAfford = canAfford,
                    buyMultiplier = buyMultiplier,
                    onBuy = { onBuyUpgrade(def.id) }
                )
            }
        }
    }
}

@Composable
fun UpgradeItemCard(
    definition: UpgradeDefinition,
    level: Int,
    buyCount: Int,
    cost: Double,
    canAfford: Boolean,
    buyMultiplier: BuyMultiplier,
    onBuy: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("upgrade_card_${definition.id}"),
        colors = CardDefaults.cardColors(
            containerColor = SpaceCard
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon in colored container
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SpaceCardElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = definition.icon,
                    contentDescription = definition.name,
                    tint = NeonCyan,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = definition.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = CosmicPurple.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Lv. $level",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CosmicPurple,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = definition.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(2.dp))

                val totalPower = definition.powerPerLevel * level
                Text(
                    text = "Current: +$totalPower/tap",
                    fontSize = 11.sp,
                    color = SupernovaGold,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Buy button
            Button(
                onClick = onBuy,
                enabled = canAfford,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = Color.Black,
                    disabledContainerColor = SpaceCardElevated,
                    disabledContentColor = TextMuted
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("buy_button_${definition.id}")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val label = if (buyMultiplier == BuyMultiplier.MAX) {
                        if (buyCount > 0) "+$buyCount" else "MAX"
                    } else {
                        "+$buyCount"
                    }
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = formatCrystals(cost),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

fun calculateUpgradeCost(
    def: UpgradeDefinition,
    level: Int,
    multiplier: BuyMultiplier,
    crystals: Double
): Pair<Int, Double> {
    return when (multiplier) {
        BuyMultiplier.X1 -> Pair(1, def.getCostForLevel(level))
        BuyMultiplier.X10 -> Pair(10, def.getTotalCost(level, 10))
        BuyMultiplier.MAX -> {
            val maxPair = def.getMaxAffordable(level, crystals)
            if (maxPair.first == 0) Pair(1, def.getCostForLevel(level)) else maxPair
        }
    }
}

fun formatCrystals(value: Double): String {
    return when {
        value >= 1_000_000_000 -> String.format("%.2fB", value / 1_000_000_000)
        value >= 1_000_000 -> String.format("%.2fM", value / 1_000_000)
        value >= 1_000 -> String.format("%.1fK", value / 1_000)
        else -> String.format("%.0f", value)
    }
}
