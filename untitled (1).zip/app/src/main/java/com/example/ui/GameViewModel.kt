package com.example.ui

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.GameRepository
import com.example.data.GameStateEntity
import com.example.model.AchievementDefinition
import com.example.model.GameRegistry
import com.example.model.UpgradeCategory
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class BuyMultiplier(val label: String) {
    X1("1x"),
    X10("10x"),
    MAX("MAX")
}

data class FloatingNumber(
    val id: Long,
    val text: String,
    val xOffsetDp: Float,
    val yOffsetDp: Float,
    val isCritical: Boolean = false
)

data class GameUiState(
    val crystals: Double = 0.0,
    val totalCrystalsMined: Double = 0.0,
    val totalClicks: Long = 0L,
    val cosmicRelics: Int = 0,
    val rebirthCount: Int = 0,
    val highestCombo: Double = 1.0,
    val currentCombo: Double = 1.0,
    val comboProgress: Float = 0f, // 0.0 to 1.0 for combo bar
    val hapticsEnabled: Boolean = true,
    val upgradeLevels: Map<String, Int> = emptyMap(),
    val unlockedAchievements: Set<String> = emptySet(),
    val buyMultiplier: BuyMultiplier = BuyMultiplier.X1,
    val floatingNumbers: List<FloatingNumber> = emptyList(),
    val offlineEarnings: Double? = null,
    val newAchievementUnlocked: AchievementDefinition? = null,
    val isLoaded: Boolean = false
) {
    val relicBonusMultiplier: Double
        get() = 1.0 + (cosmicRelics * 0.05)

    val baseCrystalsPerClick: Double
        get() {
            var power = 1.0
            GameRegistry.CLICK_UPGRADES.forEach { def ->
                val lvl = upgradeLevels[def.id] ?: 0
                power += def.powerPerLevel * lvl
            }
            return power * relicBonusMultiplier
        }

    val effectiveCrystalsPerClick: Double
        get() = baseCrystalsPerClick * currentCombo

    val effectiveCpc: Double
        get() = effectiveCrystalsPerClick

    val crystalsPerSecond: Double
        get() {
            var power = 0.0
            GameRegistry.MINER_UPGRADES.forEach { def ->
                val lvl = upgradeLevels[def.id] ?: 0
                power += def.powerPerLevel * lvl
            }
            return power * relicBonusMultiplier
        }

    val totalMinersOwned: Int
        get() {
            var count = 0
            GameRegistry.MINER_UPGRADES.forEach { def ->
                count += upgradeLevels[def.id] ?: 0
            }
            return count
        }

    val rebirthMilestoneRequirement: Double
        get() = 50000.0 * Math.pow(2.0, rebirthCount.toDouble())

    val canRebirth: Boolean
        get() = totalCrystalsMined >= rebirthMilestoneRequirement

    val potentialRelicsOnRebirth: Int
        get() {
            if (!canRebirth) return 0
            val excess = totalCrystalsMined - rebirthMilestoneRequirement
            return 1 + (excess / 35000.0).toInt()
        }
}

class GameViewModel(private val repository: GameRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var tickerJob: Job? = null
    private var comboJob: Job? = null
    private var lastTapTime = 0L
    private var floatingNumberCounter = 0L

    init {
        loadInitialData()
        startGameLoop()
    }

    private fun loadInitialData() {
        viewModelScope.launch {
            val initialState = repository.getInitialState()

            // Observe upgrades
            launch {
                repository.upgrades.collect { list ->
                    val map = list.associate { it.id to it.level }
                    _uiState.update { it.copy(upgradeLevels = map) }
                }
            }

            // Observe achievements
            launch {
                repository.achievements.collect { list ->
                    val set = list.filter { it.isUnlocked }.map { it.id }.toSet()
                    _uiState.update { it.copy(unlockedAchievements = set) }
                }
            }

            // Calculate offline earnings if any
            val now = System.currentTimeMillis()
            val elapsedSec = ((now - initialState.lastActiveTimestamp) / 1000).coerceAtLeast(0L)
            var offlineGains: Double? = null

            _uiState.update { current ->
                current.copy(
                    crystals = initialState.crystals,
                    totalCrystalsMined = initialState.totalCrystalsMined,
                    totalClicks = initialState.totalClicks,
                    cosmicRelics = initialState.cosmicRelics,
                    rebirthCount = initialState.rebirthCount,
                    highestCombo = initialState.highestCombo,
                    hapticsEnabled = initialState.hapticsEnabled,
                    isLoaded = true
                )
            }

            // If offline for > 15s and has miners
            val cps = _uiState.value.crystalsPerSecond
            if (elapsedSec > 15 && cps > 0) {
                val cappedSeconds = elapsedSec.coerceAtMost(86400L) // max 24 hours
                val generated = cappedSeconds * cps
                if (generated >= 1.0) {
                    offlineGains = generated
                    _uiState.update { it.copy(offlineEarnings = offlineGains) }
                }
            }
        }
    }

    private fun startGameLoop() {
        tickerJob = viewModelScope.launch {
            var subTicks = 0
            while (isActive) {
                delay(100) // 100ms tick for smooth increments
                val state = _uiState.value
                val cps = state.crystalsPerSecond
                if (cps > 0) {
                    val add = cps * 0.1
                    _uiState.update { current ->
                        current.copy(
                            crystals = current.crystals + add,
                            totalCrystalsMined = current.totalCrystalsMined + add
                        )
                    }
                }

                // Check achievements periodically
                subTicks++
                if (subTicks % 10 == 0) { // every 1 sec
                    checkAchievements()
                }

                // Autosave every 5 seconds (50 ticks)
                if (subTicks % 50 == 0) {
                    saveCurrentState()
                }
            }
        }
    }

    fun onCrystalTapped(context: Context) {
        val now = System.currentTimeMillis()
        val timeSinceLastTap = now - lastTapTime
        lastTapTime = now

        // Trigger subtle haptic feedback
        if (_uiState.value.hapticsEnabled) {
            triggerHaptic(context)
        }

        // Update Combo: fast tapping builds up combo up to 3.0x
        val comboBoost = if (timeSinceLastTap < 400) 0.08 else 0.03
        var newCombo = (_uiState.value.currentCombo + comboBoost).coerceAtMost(3.0)
        val highestCombo = Math.max(newCombo, _uiState.value.highestCombo)

        val clickGain = _uiState.value.baseCrystalsPerClick * newCombo
        val isCrit = newCombo >= 2.0

        // Create floating number animation
        val randomX = Random.nextInt(-70, 70).toFloat()
        val randomY = Random.nextInt(-40, 20).toFloat()
        val floatingText = if (isCrit) {
            String.format("+%.1f (x%.1f)", clickGain, newCombo)
        } else if (clickGain >= 10) {
            String.format("+%.0f", clickGain)
        } else {
            String.format("+%.1f", clickGain)
        }

        val newFloatingNumber = FloatingNumber(
            id = ++floatingNumberCounter,
            text = floatingText,
            xOffsetDp = randomX,
            yOffsetDp = randomY,
            isCritical = isCrit
        )

        _uiState.update { current ->
            val updatedList = (current.floatingNumbers + newFloatingNumber).takeLast(8)
            current.copy(
                crystals = current.crystals + clickGain,
                totalCrystalsMined = current.totalCrystalsMined + clickGain,
                totalClicks = current.totalClicks + 1,
                currentCombo = newCombo,
                highestCombo = highestCombo,
                comboProgress = ((newCombo - 1.0) / 2.0).toFloat().coerceIn(0f, 1f),
                floatingNumbers = updatedList
            )
        }

        // Schedule combo decay
        resetComboDecayTimer()

        // Clean up floating number after 800ms
        viewModelScope.launch {
            delay(800)
            _uiState.update { current ->
                current.copy(floatingNumbers = current.floatingNumbers.filter { it.id != newFloatingNumber.id })
            }
        }

        checkAchievements()
    }

    private fun resetComboDecayTimer() {
        comboJob?.cancel()
        comboJob = viewModelScope.launch {
            delay(1200) // 1.2s delay before decaying
            while (isActive && _uiState.value.currentCombo > 1.0) {
                delay(100)
                _uiState.update { current ->
                    val decayed = (current.currentCombo - 0.1).coerceAtLeast(1.0)
                    current.copy(
                        currentCombo = decayed,
                        comboProgress = ((decayed - 1.0) / 2.0).toFloat().coerceIn(0f, 1f)
                    )
                }
            }
        }
    }

    fun buyUpgrade(upgradeId: String) {
        val def = GameRegistry.ALL_UPGRADES.find { it.id == upgradeId } ?: return
        val currentLvl = _uiState.value.upgradeLevels[upgradeId] ?: 0
        val multiplier = _uiState.value.buyMultiplier
        val currentCrystals = _uiState.value.crystals

        val (levelsToBuy, totalCost) = when (multiplier) {
            BuyMultiplier.X1 -> {
                val cost = def.getCostForLevel(currentLvl)
                if (currentCrystals >= cost) Pair(1, cost) else Pair(0, 0.0)
            }
            BuyMultiplier.X10 -> {
                val cost = def.getTotalCost(currentLvl, 10)
                if (currentCrystals >= cost) Pair(10, cost) else Pair(0, 0.0)
            }
            BuyMultiplier.MAX -> {
                def.getMaxAffordable(currentLvl, currentCrystals)
            }
        }

        if (levelsToBuy > 0 && currentCrystals >= totalCost) {
            val newLevel = currentLvl + levelsToBuy
            val updatedMap = _uiState.value.upgradeLevels.toMutableMap()
            updatedMap[upgradeId] = newLevel

            _uiState.update { current ->
                current.copy(
                    crystals = current.crystals - totalCost,
                    upgradeLevels = updatedMap
                )
            }

            viewModelScope.launch {
                repository.saveUpgradeLevel(upgradeId, newLevel)
                saveCurrentState()
            }

            checkAchievements()
        }
    }

    fun toggleBuyMultiplier() {
        val next = when (_uiState.value.buyMultiplier) {
            BuyMultiplier.X1 -> BuyMultiplier.X10
            BuyMultiplier.X10 -> BuyMultiplier.MAX
            BuyMultiplier.MAX -> BuyMultiplier.X1
        }
        _uiState.update { it.copy(buyMultiplier = next) }
    }

    fun claimOfflineEarnings() {
        val amount = _uiState.value.offlineEarnings ?: return
        _uiState.update { current ->
            current.copy(
                crystals = current.crystals + amount,
                totalCrystalsMined = current.totalCrystalsMined + amount,
                offlineEarnings = null
            )
        }
        saveCurrentState()
    }

    fun dismissOfflineEarnings() {
        _uiState.update { it.copy(offlineEarnings = null) }
    }

    fun performRebirth() {
        val state = _uiState.value
        if (!state.canRebirth) return

        val relicsGained = state.potentialRelicsOnRebirth
        viewModelScope.launch {
            repository.executeRebirth(relicsGained, state.cosmicRelics, state.rebirthCount)
            _uiState.update { current ->
                current.copy(
                    crystals = 0.0,
                    totalCrystalsMined = 0.0,
                    totalClicks = 0L,
                    cosmicRelics = current.cosmicRelics + relicsGained,
                    rebirthCount = current.rebirthCount + 1,
                    upgradeLevels = emptyMap(),
                    currentCombo = 1.0,
                    comboProgress = 0f
                )
            }
            checkAchievements()
        }
    }

    fun toggleHaptics() {
        val newHaptics = !_uiState.value.hapticsEnabled
        _uiState.update { it.copy(hapticsEnabled = newHaptics) }
        saveCurrentState()
    }

    fun resetGame() {
        viewModelScope.launch {
            repository.resetAllGameData()
            _uiState.update {
                GameUiState(
                    crystals = 0.0,
                    totalCrystalsMined = 0.0,
                    totalClicks = 0L,
                    cosmicRelics = 0,
                    rebirthCount = 0,
                    highestCombo = 1.0,
                    currentCombo = 1.0,
                    comboProgress = 0f,
                    hapticsEnabled = true,
                    upgradeLevels = emptyMap(),
                    unlockedAchievements = emptySet(),
                    isLoaded = true
                )
            }
        }
    }

    fun dismissAchievementBanner() {
        _uiState.update { it.copy(newAchievementUnlocked = null) }
    }

    private fun checkAchievements() {
        val state = _uiState.value
        val unlocked = state.unlockedAchievements

        GameRegistry.ACHIEVEMENTS.forEach { ach ->
            if (!unlocked.contains(ach.id)) {
                val shouldUnlock = when (ach.id) {
                    "ach_first_tap" -> state.totalClicks >= 1
                    "ach_clicks_100" -> state.totalClicks >= 100
                    "ach_clicks_1000" -> state.totalClicks >= 1000
                    "ach_crystals_1000" -> state.totalCrystalsMined >= 1000.0
                    "ach_crystals_50000" -> state.totalCrystalsMined >= 50000.0
                    "ach_combo_2x" -> state.highestCombo >= 2.0
                    "ach_automation_10" -> state.totalMinersOwned >= 10
                    "ach_first_rebirth" -> state.rebirthCount >= 1
                    else -> false
                }

                if (shouldUnlock) {
                    unlockAchievement(ach)
                }
            }
        }
    }

    private fun unlockAchievement(ach: AchievementDefinition) {
        viewModelScope.launch {
            repository.saveAchievementUnlocked(ach.id)
            _uiState.update { current ->
                val newUnlocked = current.unlockedAchievements + ach.id
                current.copy(
                    unlockedAchievements = newUnlocked,
                    crystals = current.crystals + ach.rewardCrystals,
                    totalCrystalsMined = current.totalCrystalsMined + ach.rewardCrystals,
                    newAchievementUnlocked = ach
                )
            }
            delay(3500)
            if (_uiState.value.newAchievementUnlocked?.id == ach.id) {
                _uiState.update { it.copy(newAchievementUnlocked = null) }
            }
        }
    }

    private fun saveCurrentState() {
        val s = _uiState.value
        viewModelScope.launch {
            repository.saveGameState(
                GameStateEntity(
                    id = 1,
                    crystals = s.crystals,
                    totalCrystalsMined = s.totalCrystalsMined,
                    totalClicks = s.totalClicks,
                    cosmicRelics = s.cosmicRelics,
                    rebirthCount = s.rebirthCount,
                    highestCombo = s.highestCombo,
                    hapticsEnabled = s.hapticsEnabled,
                    lastActiveTimestamp = System.currentTimeMillis()
                )
            )
        }
    }

    private fun triggerHaptic(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(12)
                }
            }
        } catch (_: Exception) {
            // Graceful fallback if device has no vibrator
        }
    }

    override fun onCleared() {
        super.onCleared()
        saveCurrentState()
        tickerJob?.cancel()
        comboJob?.cancel()
    }
}

class GameViewModelFactory(private val repository: GameRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GameViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return GameViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
