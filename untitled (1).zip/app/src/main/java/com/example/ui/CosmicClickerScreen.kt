package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CrystalCore
import com.example.ui.components.MinersView
import com.example.ui.components.RebirthView
import com.example.ui.components.StatsAndBadgesView
import com.example.ui.components.UpgradesView
import com.example.ui.components.formatCrystals
import com.example.ui.theme.CosmicPurple
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SpaceBlack
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SpaceCardElevated
import com.example.ui.theme.SupernovaGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

enum class GameTab(val title: String, val icon: ImageVector, val tag: String) {
    CORE("Core", Icons.Default.TouchApp, "nav_core"),
    UPGRADES("Click", Icons.Default.FlashOn, "nav_upgrades"),
    MINERS("Miners", Icons.Default.PrecisionManufacturing, "nav_miners"),
    REBIRTH("Ascend", Icons.Default.Public, "nav_rebirth"),
    STATS("Stats", Icons.Default.MilitaryTech, "nav_stats")
}

@Composable
fun CosmicClickerScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    // Android back handler to return to core screen if in secondary tab
    BackHandler(enabled = selectedTab != 0) {
        selectedTab = 0
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = SpaceBlack,
        bottomBar = {
            NavigationBar(
                containerColor = SpaceCard,
                contentColor = NeonCyan,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("game_navigation_bar")
            ) {
                GameTab.values().forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag(tab.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Header: Crystals Count & Rates
                TopResourceHeader(
                    crystals = state.crystals,
                    crystalsPerSecond = state.crystalsPerSecond,
                    effectiveCpc = state.effectiveCpc,
                    cosmicRelics = state.cosmicRelics
                )

                // Tab Content
                when (selectedTab) {
                    0 -> {
                        CrystalCore(
                            currentCombo = state.currentCombo,
                            comboProgress = state.comboProgress,
                            effectiveCpc = state.effectiveCpc,
                            floatingNumbers = state.floatingNumbers,
                            onTap = { viewModel.onCrystalTapped(context) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    1 -> {
                        UpgradesView(
                            crystals = state.crystals,
                            upgradeLevels = state.upgradeLevels,
                            buyMultiplier = state.buyMultiplier,
                            onToggleMultiplier = { viewModel.toggleBuyMultiplier() },
                            onBuyUpgrade = { id -> viewModel.buyUpgrade(id) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    2 -> {
                        MinersView(
                            crystals = state.crystals,
                            crystalsPerSecond = state.crystalsPerSecond,
                            upgradeLevels = state.upgradeLevels,
                            buyMultiplier = state.buyMultiplier,
                            onToggleMultiplier = { viewModel.toggleBuyMultiplier() },
                            onBuyUpgrade = { id -> viewModel.buyUpgrade(id) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    3 -> {
                        RebirthView(
                            cosmicRelics = state.cosmicRelics,
                            rebirthCount = state.rebirthCount,
                            totalCrystalsMined = state.totalCrystalsMined,
                            milestoneRequirement = state.rebirthMilestoneRequirement,
                            potentialRelics = state.potentialRelicsOnRebirth,
                            canRebirth = state.canRebirth,
                            onPerformRebirth = { viewModel.performRebirth() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    4 -> {
                        StatsAndBadgesView(
                            totalClicks = state.totalClicks,
                            totalCrystalsMined = state.totalCrystalsMined,
                            highestCombo = state.highestCombo,
                            rebirthCount = state.rebirthCount,
                            cosmicRelics = state.cosmicRelics,
                            totalMiners = state.totalMinersOwned,
                            unlockedAchievements = state.unlockedAchievements,
                            hapticsEnabled = state.hapticsEnabled,
                            onToggleHaptics = { viewModel.toggleHaptics() },
                            onResetGame = { viewModel.resetGame() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Top floating achievement unlock toast
            AnimatedVisibility(
                visible = state.newAchievementUnlocked != null,
                enter = slideInVertically(initialOffsetY = { -it }),
                exit = slideOutVertically(targetOffsetY = { -it }),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
            ) {
                state.newAchievementUnlocked?.let { ach ->
                    AchievementToast(
                        title = ach.title,
                        reward = ach.rewardCrystals,
                        onDismiss = { viewModel.dismissAchievementBanner() }
                    )
                }
            }

            // Offline earnings modal dialog
            state.offlineEarnings?.let { amount ->
                OfflineEarningsDialog(
                    amount = amount,
                    onClaim = { viewModel.claimOfflineEarnings() },
                    onDismiss = { viewModel.dismissOfflineEarnings() }
                )
            }
        }
    }
}

@Composable
fun TopResourceHeader(
    crystals: Double,
    crystalsPerSecond: Double,
    effectiveCpc: Double,
    cosmicRelics: Int
) {
    Surface(
        color = SpaceCard,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("top_resource_header")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Relics badge if any
            if (cosmicRelics > 0) {
                Surface(
                    color = SupernovaGold.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "Relics",
                            tint = SupernovaGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$cosmicRelics Relics (+${cosmicRelics * 5}%)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SupernovaGold
                        )
                    }
                }
            }

            // Big Crystal count
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Crystals",
                    tint = NeonCyan,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = formatCrystals(crystals),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onSurface,
                    letterSpacing = 1.sp
                )
            }

            Text(
                text = "CRYSTALS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Rates bar (Per Second & Per Click)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Surface(
                    color = SpaceCardElevated,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PrecisionManufacturing,
                            contentDescription = null,
                            tint = EmeraldGlow,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "+${formatCrystals(crystalsPerSecond)}/s",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = EmeraldGlow
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Surface(
                    color = SpaceCardElevated,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlashOn,
                            contentDescription = null,
                            tint = SupernovaGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "+${formatCrystals(effectiveCpc)}/tap",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SupernovaGold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AchievementToast(
    title: String,
    reward: Double,
    onDismiss: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SupernovaGold),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("achievement_unlock_toast")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MilitaryTech,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "BADGE UNLOCKED!",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.Black.copy(alpha = 0.7f),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "$title (+${formatCrystals(reward)} crystals)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = Color.Black,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun OfflineEarningsDialog(
    amount: Double,
    onClaim: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Sensors,
                    contentDescription = null,
                    tint = EmeraldGlow,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Welcome Back, Commander!",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "While you were away from the cosmos, your automated mining fleet worked tirelessly and gathered:",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    color = SpaceCardElevated,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "+${formatCrystals(amount)} Crystals",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = NeonCyan
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onClaim,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("claim_offline_crystals_button")
            ) {
                Text("Claim Crystals", fontWeight = FontWeight.Bold)
            }
        },
        containerColor = SpaceCard
    )
}
