package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class GameRepository(private val gameDao: GameDao) {

    val gameState: Flow<GameStateEntity?> = gameDao.getGameState()
    val upgrades: Flow<List<UpgradeEntity>> = gameDao.getAllUpgrades()
    val achievements: Flow<List<AchievementEntity>> = gameDao.getAllAchievements()

    suspend fun getInitialState(): GameStateEntity = withContext(Dispatchers.IO) {
        val existing = gameDao.getGameStateOnce()
        if (existing == null) {
            val defaultState = GameStateEntity(
                id = 1,
                crystals = 0.0,
                totalCrystalsMined = 0.0,
                totalClicks = 0L,
                cosmicRelics = 0,
                rebirthCount = 0,
                highestCombo = 1.0,
                hapticsEnabled = true,
                lastActiveTimestamp = System.currentTimeMillis()
            )
            gameDao.saveGameState(defaultState)
            defaultState
        } else {
            existing
        }
    }

    suspend fun saveGameState(state: GameStateEntity) = withContext(Dispatchers.IO) {
        gameDao.saveGameState(state)
    }

    suspend fun saveUpgradeLevel(upgradeId: String, newLevel: Int) = withContext(Dispatchers.IO) {
        gameDao.saveUpgrade(UpgradeEntity(id = upgradeId, level = newLevel))
    }

    suspend fun saveAchievementUnlocked(achievementId: String) = withContext(Dispatchers.IO) {
        gameDao.saveAchievement(AchievementEntity(id = achievementId, isUnlocked = true, unlockedAt = System.currentTimeMillis()))
    }

    suspend fun resetAllGameData() = withContext(Dispatchers.IO) {
        gameDao.clearGameState()
        gameDao.clearUpgrades()
        gameDao.clearAchievements()
        val fresh = GameStateEntity(
            id = 1,
            crystals = 0.0,
            totalCrystalsMined = 0.0,
            totalClicks = 0L,
            cosmicRelics = 0,
            rebirthCount = 0,
            highestCombo = 1.0,
            hapticsEnabled = true,
            lastActiveTimestamp = System.currentTimeMillis()
        )
        gameDao.saveGameState(fresh)
    }

    suspend fun executeRebirth(newRelicsGained: Int, currentRelics: Int, rebirthCount: Int) = withContext(Dispatchers.IO) {
        gameDao.clearUpgrades()
        val postRebirthState = GameStateEntity(
            id = 1,
            crystals = 0.0,
            totalCrystalsMined = 0.0,
            totalClicks = 0L,
            cosmicRelics = currentRelics + newRelicsGained,
            rebirthCount = rebirthCount + 1,
            highestCombo = 1.0,
            hapticsEnabled = true,
            lastActiveTimestamp = System.currentTimeMillis()
        )
        gameDao.saveGameState(postRebirthState)
    }
}
