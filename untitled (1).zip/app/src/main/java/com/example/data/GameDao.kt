package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM game_state WHERE id = 1 LIMIT 1")
    fun getGameState(): Flow<GameStateEntity?>

    @Query("SELECT * FROM game_state WHERE id = 1 LIMIT 1")
    suspend fun getGameStateOnce(): GameStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveGameState(state: GameStateEntity)

    @Query("SELECT * FROM upgrades")
    fun getAllUpgrades(): Flow<List<UpgradeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUpgrade(upgrade: UpgradeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUpgrades(upgrades: List<UpgradeEntity>)

    @Query("SELECT * FROM achievements")
    fun getAllAchievements(): Flow<List<AchievementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAchievement(achievement: AchievementEntity)

    @Query("DELETE FROM game_state")
    suspend fun clearGameState()

    @Query("DELETE FROM upgrades")
    suspend fun clearUpgrades()

    @Query("DELETE FROM achievements")
    suspend fun clearAchievements()
}
