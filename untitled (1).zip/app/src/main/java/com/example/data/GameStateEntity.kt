package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_state")
data class GameStateEntity(
    @PrimaryKey val id: Int = 1,
    val crystals: Double = 0.0,
    val totalCrystalsMined: Double = 0.0,
    val totalClicks: Long = 0L,
    val cosmicRelics: Int = 0,
    val rebirthCount: Int = 0,
    val highestCombo: Double = 1.0,
    val hapticsEnabled: Boolean = true,
    val lastActiveTimestamp: Long = System.currentTimeMillis()
)
