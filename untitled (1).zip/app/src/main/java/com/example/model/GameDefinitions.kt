package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.ui.graphics.vector.ImageVector

enum class UpgradeCategory {
    CLICK_POWER,
    AUTOMATED_MINER
}

data class UpgradeDefinition(
    val id: String,
    val name: String,
    val description: String,
    val category: UpgradeCategory,
    val baseCost: Double,
    val costMultiplier: Double = 1.15,
    val powerPerLevel: Double,
    val icon: ImageVector
) {
    fun getCostForLevel(currentLevel: Int): Double {
        return baseCost * Math.pow(costMultiplier, currentLevel.toDouble())
    }

    fun getTotalCost(currentLevel: Int, count: Int): Double {
        var total = 0.0
        for (i in 0 until count) {
            total += baseCost * Math.pow(costMultiplier, (currentLevel + i).toDouble())
        }
        return total
    }

    fun getMaxAffordable(currentLevel: Int, availableCrystals: Double): Pair<Int, Double> {
        var count = 0
        var totalCost = 0.0
        var nextCost = getCostForLevel(currentLevel)
        while (totalCost + nextCost <= availableCrystals && count < 1000) {
            totalCost += nextCost
            count++
            nextCost = baseCost * Math.pow(costMultiplier, (currentLevel + count).toDouble())
        }
        return Pair(count, totalCost)
    }
}

data class AchievementDefinition(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val rewardCrystals: Double
)

object GameRegistry {
    val CLICK_UPGRADES = listOf(
        UpgradeDefinition(
            id = "click_laser",
            name = "Plasma Pickaxe",
            description = "+1 crystal per tap",
            category = UpgradeCategory.CLICK_POWER,
            baseCost = 15.0,
            costMultiplier = 1.14,
            powerPerLevel = 1.0,
            icon = Icons.Filled.FlashOn
        ),
        UpgradeDefinition(
            id = "click_quantum",
            name = "Quantum Extractor",
            description = "+5 crystals per tap",
            category = UpgradeCategory.CLICK_POWER,
            baseCost = 150.0,
            costMultiplier = 1.15,
            powerPerLevel = 5.0,
            icon = Icons.Filled.ElectricBolt
        ),
        UpgradeDefinition(
            id = "click_singularity",
            name = "Singularity Gauntlet",
            description = "+25 crystals per tap",
            category = UpgradeCategory.CLICK_POWER,
            baseCost = 1200.0,
            costMultiplier = 1.16,
            powerPerLevel = 25.0,
            icon = Icons.Filled.Bolt
        ),
        UpgradeDefinition(
            id = "click_hyperdrive",
            name = "Cosmic Resonance Core",
            description = "+120 crystals per tap",
            category = UpgradeCategory.CLICK_POWER,
            baseCost = 8500.0,
            costMultiplier = 1.17,
            powerPerLevel = 120.0,
            icon = Icons.Filled.Star
        ),
        UpgradeDefinition(
            id = "click_celestial",
            name = "Celestial Overdriver",
            description = "+600 crystals per tap",
            category = UpgradeCategory.CLICK_POWER,
            baseCost = 65000.0,
            costMultiplier = 1.18,
            powerPerLevel = 600.0,
            icon = Icons.Filled.Shield
        )
    )

    val MINER_UPGRADES = listOf(
        UpgradeDefinition(
            id = "miner_drone",
            name = "Mining Drone",
            description = "Automated probe that gathers crystals (+1/sec)",
            category = UpgradeCategory.AUTOMATED_MINER,
            baseCost = 30.0,
            costMultiplier = 1.15,
            powerPerLevel = 1.0,
            icon = Icons.Filled.Sensors
        ),
        UpgradeDefinition(
            id = "miner_drill",
            name = "Sub-Surface Drill",
            description = "Bores deep into planetary crust (+5/sec)",
            category = UpgradeCategory.AUTOMATED_MINER,
            baseCost = 180.0,
            costMultiplier = 1.15,
            powerPerLevel = 5.0,
            icon = Icons.Filled.PrecisionManufacturing
        ),
        UpgradeDefinition(
            id = "miner_satellite",
            name = "Orbital Harvester",
            description = "Collects floating crystalline debris (+25/sec)",
            category = UpgradeCategory.AUTOMATED_MINER,
            baseCost = 1400.0,
            costMultiplier = 1.16,
            powerPerLevel = 25.0,
            icon = Icons.Filled.SatelliteAlt
        ),
        UpgradeDefinition(
            id = "miner_colony",
            name = "Asteroid Mining Base",
            description = "Heavy industrial station stationed on mineral belt (+120/sec)",
            category = UpgradeCategory.AUTOMATED_MINER,
            baseCost = 9000.0,
            costMultiplier = 1.16,
            powerPerLevel = 120.0,
            icon = Icons.Filled.RocketLaunch
        ),
        UpgradeDefinition(
            id = "miner_dyson",
            name = "Dyson Sphere Segment",
            description = "Harnesses stellar radiation directly into crystals (+650/sec)",
            category = UpgradeCategory.AUTOMATED_MINER,
            baseCost = 55000.0,
            costMultiplier = 1.17,
            powerPerLevel = 650.0,
            icon = Icons.Filled.Public
        ),
        UpgradeDefinition(
            id = "miner_rift",
            name = "Galactic Wormhole Rift",
            description = "Channels unlimited energy from alternate cosmos (+3500/sec)",
            category = UpgradeCategory.AUTOMATED_MINER,
            baseCost = 350000.0,
            costMultiplier = 1.18,
            powerPerLevel = 3500.0,
            icon = Icons.Filled.Star
        )
    )

    val ALL_UPGRADES = CLICK_UPGRADES + MINER_UPGRADES

    val ACHIEVEMENTS = listOf(
        AchievementDefinition(
            id = "ach_first_tap",
            title = "First Spark",
            description = "Click the Cosmic Crystal for the first time.",
            icon = Icons.Filled.FlashOn,
            rewardCrystals = 25.0
        ),
        AchievementDefinition(
            id = "ach_clicks_100",
            title = "Kinetic Enthusiast",
            description = "Reach 100 total taps.",
            icon = Icons.Filled.Bolt,
            rewardCrystals = 250.0
        ),
        AchievementDefinition(
            id = "ach_clicks_1000",
            title = "Hyper-Tapper",
            description = "Reach 1,000 total taps.",
            icon = Icons.Filled.ElectricBolt,
            rewardCrystals = 2500.0
        ),
        AchievementDefinition(
            id = "ach_crystals_1000",
            title = "Crystal Novice",
            description = "Accumulate 1,000 lifetime crystals.",
            icon = Icons.Filled.Star,
            rewardCrystals = 500.0
        ),
        AchievementDefinition(
            id = "ach_crystals_50000",
            title = "Starlight Tycoon",
            description = "Accumulate 50,000 lifetime crystals.",
            icon = Icons.Filled.Shield,
            rewardCrystals = 10000.0
        ),
        AchievementDefinition(
            id = "ach_combo_2x",
            title = "Rhythm Master",
            description = "Reach a x2.0 combo multiplier by tapping rapidly.",
            icon = Icons.Filled.FlashOn,
            rewardCrystals = 1000.0
        ),
        AchievementDefinition(
            id = "ach_automation_10",
            title = "Industrialist",
            description = "Own at least 10 automated miners.",
            icon = Icons.Filled.PrecisionManufacturing,
            rewardCrystals = 3000.0
        ),
        AchievementDefinition(
            id = "ach_first_rebirth",
            title = "Cosmic Ascendant",
            description = "Perform your first Cosmic Rebirth.",
            icon = Icons.Filled.Public,
            rewardCrystals = 25000.0
        )
    )
}
