package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Cosmic Clicker", appName)
  }

  @Test
  fun `upgrade cost calculations are accurate`() {
    val upgrade = com.example.model.GameRegistry.CLICK_UPGRADES.first()
    val baseCost = upgrade.getCostForLevel(0)
    assertEquals(15.0, baseCost, 0.01)

    val nextCost = upgrade.getCostForLevel(1)
    assertEquals(15.0 * 1.14, nextCost, 0.01)
  }
}
